package com.mycompany.aula20250224;

public class SoDados {
    
    int i;
    float f;
    boolean b;
    
    void Imprimir(){
        System.out.println("Valor de i: "+i);
        System.out.println("Valor de f: "+f);
        System.out.println("Valor de b: "+b);
    }
    
}
