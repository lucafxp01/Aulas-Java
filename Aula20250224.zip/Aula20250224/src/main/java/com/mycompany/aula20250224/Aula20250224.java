package com.mycompany.aula20250224;

public class Aula20250224 {

    public static void main(String[] args) {
        System.out.println("Aprendendo classes");
        
        /*SoDados sd;       
        sd = new SoDados();

        sd.i = 10;
        sd.f = (float) 10.0;
        sd.b = true;
        
        sd.Imprimir();*/
        //System.out.println("Valor de i: "+sd.i);
        
        Conta c = new Conta();
        c.dono = "Cassio";
        c.limite = 1000000;
        c.numero = 10;
        c.saldo = 1000000;
        
        c.Imprimir();
        c.Depositar(100);
        c.Sacar(200);
        c.Imprimir();
        
        
    }
}
